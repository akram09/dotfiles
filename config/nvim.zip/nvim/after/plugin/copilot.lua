-- Enable yaml support for copilot

vim.g.copilot_filetypes = {yaml = true, yml = true}


-- setting up color scheme 


require("catppuccin").setup({
	flavor = "mocha",	

})

vim.cmd.colorscheme "catppuccin"
